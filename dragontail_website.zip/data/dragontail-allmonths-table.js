$(function() {
    var table = document.createElement("table");
	table.className = "table table-striped table-bordered table-hover table-condensed";
	var header = table.createTHead();
	header.className = "h4";





	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "";	
    var cell = row.insertCell(1);
    cell.innerHTML = "";
	var cell = row.insertCell(2);
    cell.innerHTML = "";
	var cell = row.insertCell(3);
    cell.innerHTML = "";
	var cell = row.insertCell(4);
    cell.innerHTML = "";
	var cell = row.insertCell(5);
    cell.innerHTML = "";
	var cell = row.insertCell(6);
    cell.innerHTML = "";
	var cell = row.insertCell(7);
    cell.innerHTML = "";
	var cell = row.insertCell(8);
    cell.innerHTML = "";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "February 2012";	
    var cell = row.insertCell(1);
    cell.innerHTML = "18.3 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "8.6 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "1.2 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "11.2 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "3.8 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-4.9 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "21.0 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "11";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "March 2012";	
    var cell = row.insertCell(1);
    cell.innerHTML = "20.5 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "13.8 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "7.4 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "10.0 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "6.1 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "1.7 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "9.6 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "6";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "April 2012";	
    var cell = row.insertCell(1);
    cell.innerHTML = "17.4 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "11.9 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "6.4 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "10.8 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "5.2 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-1.3 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "86.7 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "25";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "May 2012";	
    var cell = row.insertCell(1);
    cell.innerHTML = "26.7 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "17.3 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "10.6 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "13.7 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "8.3 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "0.0 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "33.9 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "14";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "June 2012";	
    var cell = row.insertCell(1);
    cell.innerHTML = "26.5 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "18.3 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "9.9 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "16.1 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "10.7 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "6.7 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "92.7 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "18";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "July 2012";	
    var cell = row.insertCell(1);
    cell.innerHTML = "28.5 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "20.4 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "14.1 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "16.1 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "12.8 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "9.0 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "67.8 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "20";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "August 2012";	
    var cell = row.insertCell(1);
    cell.innerHTML = "28.5 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "22.1 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "17.4 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "17.0 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "13.3 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "8.1 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "48.0 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "20";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "September 2012";	
    var cell = row.insertCell(1);
    cell.innerHTML = "26.4 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "18.4 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "10.7 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "15.7 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "10.1 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "2.6 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "121.8 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "19";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "October 2012";	
    var cell = row.insertCell(1);
    cell.innerHTML = "17.6 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "15.2 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "11.0 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "8.9 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "6.5 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "2.8 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "41.7 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "4";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "November 2012";	
    var cell = row.insertCell(1);
    cell.innerHTML = "15.3 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "10.4 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "6.6 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "12.0 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "4.9 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-1.6 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "79.2 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "21";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "December 2012";	
    var cell = row.insertCell(1);
    cell.innerHTML = "13.1 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "7.7 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "-1.1 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "12.9 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "3.6 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-3.8 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "94.8 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "27";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "March 2013";	
    var cell = row.insertCell(1);
    cell.innerHTML = "11.7 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "7.7 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "3.9 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "5.8 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "2.8 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-1.0 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "15.0 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "4";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "April 2013";	
    var cell = row.insertCell(1);
    cell.innerHTML = "19.1 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "12.0 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "7.1 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "12.8 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "4.7 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-2.9 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "12.6 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "7";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "May 2013";	
    var cell = row.insertCell(1);
    cell.innerHTML = "19.8 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "15.7 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "11.9 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "12.2 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "7.3 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "3.3 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "94.5 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "16";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "June 2013";	
    var cell = row.insertCell(1);
    cell.innerHTML = "23.1 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "21.3 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "18.9 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "14.8 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "10.4 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "8.5 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "3.9 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "3";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "September 2013";	
    var cell = row.insertCell(1);
    cell.innerHTML = "";
	var cell = row.insertCell(2);
    cell.innerHTML = "";
	var cell = row.insertCell(3);
    cell.innerHTML = "";
	var cell = row.insertCell(4);
    cell.innerHTML = "11.7 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "11.7 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "11.7 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "0";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "October 2013";	
    var cell = row.insertCell(1);
    cell.innerHTML = "21.6 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "16.9 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "10.9 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "16.0 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "10.1 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "4.3 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "92.7 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "21";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "November 2013";	
    var cell = row.insertCell(1);
    cell.innerHTML = "15.5 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "11.5 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "8.3 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "9.0 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "4.6 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-1.2 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "28.5 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "13";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "December 2013";	
    var cell = row.insertCell(1);
    cell.innerHTML = "14.9 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "9.7 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "4.8 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "9.5 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "4.0 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-0.1 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "273.6 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "16";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "January 2014";	
    var cell = row.insertCell(1);
    cell.innerHTML = "12.6 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "8.8 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "4.0 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "8.2 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "3.6 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-0.4 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "171.3 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "27";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "February 2014";	
    var cell = row.insertCell(1);
    cell.innerHTML = "14.2 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "9.9 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "7.4 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "8.6 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "4.0 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-0.2 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "533.1 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "23";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "March 2014";	
    var cell = row.insertCell(1);
    cell.innerHTML = "22.1 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "13.5 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "7.0 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "10.0 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "4.5 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-0.5 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "51.3 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "17";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "April 2014";	
    var cell = row.insertCell(1);
    cell.innerHTML = "23.3 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "17.1 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "13.1 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "12.3 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "7.3 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "2.2 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "44.1 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "13";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "May 2014";	
    var cell = row.insertCell(1);
    cell.innerHTML = "27.0 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "18.4 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "14.1 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "11.7 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "9.0 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "3.4 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "112.2 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "17";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "June 2014";	
    var cell = row.insertCell(1);
    cell.innerHTML = "26.6 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "22.6 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "15.8 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "14.9 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "11.9 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "6.2 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "35.7 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "14";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "July 2014";	
    var cell = row.insertCell(1);
    cell.innerHTML = "33.6 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "25.9 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "17.9 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "17.1 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "13.8 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "9.8 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "48.6 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "12";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "August 2014";	
    var cell = row.insertCell(1);
    cell.innerHTML = "26.5 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "21.8 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "17.5 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "15.2 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "12.6 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "10.9 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "77.4 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "12";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "September 2014";	
    var cell = row.insertCell(1);
    cell.innerHTML = "27.4 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "22.6 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "16.3 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "15.2 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "11.4 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "7.0 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "6.0 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "1";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "October 2014";	
    var cell = row.insertCell(1);
    cell.innerHTML = "21.5 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "17.2 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "11.6 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "15.4 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "9.4 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "3.4 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "70.5 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "19";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "November 2014";	
    var cell = row.insertCell(1);
    cell.innerHTML = "17.3 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "12.8 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "7.5 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "10.9 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "6.0 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "1.1 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "32.1 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "18";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "December 2014";	
    var cell = row.insertCell(1);
    cell.innerHTML = "15.5 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "9.5 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "4.8 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "12.2 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "4.2 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-2.7 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "76.5 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "26";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "January 2015";	
    var cell = row.insertCell(1);
    cell.innerHTML = "14.6 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "8.4 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "3.6 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "8.4 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "2.6 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-3.0 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "423.6 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "27";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "February 2015";	
    var cell = row.insertCell(1);
    cell.innerHTML = "13.1 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "8.4 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "4.0 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "7.2 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "2.3 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-3.5 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "15.3 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "13";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "March 2015";	
    var cell = row.insertCell(1);
    cell.innerHTML = "16.1 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "11.7 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "6.0 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "9.3 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "3.4 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-0.8 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "109.2 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "18";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "April 2015";	
    var cell = row.insertCell(1);
    cell.innerHTML = "23.0 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "16.1 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "9.6 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "11.0 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "4.8 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "0.9 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "175.5 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "8";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "May 2015";	
    var cell = row.insertCell(1);
    cell.innerHTML = "23.4 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "16.9 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "9.3 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "13.3 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "8.2 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "4.9 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "48.6 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "14";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "June 2015";	
    var cell = row.insertCell(1);
    cell.innerHTML = "31.5 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "21.8 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "12.0 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "18.3 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "10.9 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "5.8 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "17.4 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "10";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "July 2015";	
    var cell = row.insertCell(1);
    cell.innerHTML = "28.8 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "21.6 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "14.0 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "16.1 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "12.2 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "7.9 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "34.5 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "7";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "August 2015";	
    var cell = row.insertCell(1);
    cell.innerHTML = "30.1 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "22.9 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "16.2 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "17.4 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "12.2 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "7.9 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "61.5 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "15";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "September 2015";	
    var cell = row.insertCell(1);
    cell.innerHTML = "27.6 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "20.7 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "15.5 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "12.4 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "9.2 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "5.3 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "43.2 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "7";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "October 2015";	
    var cell = row.insertCell(1);
    cell.innerHTML = "26.7 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "17.9 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "12.8 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "14.5 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "8.1 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "2.7 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "31.8 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "6";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "November 2015";	
    var cell = row.insertCell(1);
    cell.innerHTML = "18.6 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "13.0 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "7.1 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "15.7 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "7.6 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-1.1 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "376.2 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "24";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "December 2015";	
    var cell = row.insertCell(1);
    cell.innerHTML = "16.3 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "12.3 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "6.1 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "12.6 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "7.6 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "0.6 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "65.1 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "24";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "January 2016";	
    var cell = row.insertCell(1);
    cell.innerHTML = "15.7 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "9.4 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "2.7 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "11.7 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "4.4 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-2.0 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "366.0 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "26";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "February 2016";	
    var cell = row.insertCell(1);
    cell.innerHTML = "15.1 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "9.5 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "5.5 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "9.6 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "2.7 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-2.0 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "295.5 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "11";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "March 2016";	
    var cell = row.insertCell(1);
    cell.innerHTML = "18.6 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "11.6 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "5.3 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "8.0 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "3.2 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "-0.5 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "28.5 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "13";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "April 2016";	
    var cell = row.insertCell(1);
    cell.innerHTML = "22.0 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "13.8 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "8.2 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "7.4 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "4.5 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "0.1 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "54.9 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "20";	


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "May 2016";	
    var cell = row.insertCell(1);
    cell.innerHTML = "29.9 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "20.7 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "13.2 &deg;C";
	var cell = row.insertCell(4);
    cell.innerHTML = "13.3 &deg;C";
	var cell = row.insertCell(5);
    cell.innerHTML = "8.9 &deg;C";
	var cell = row.insertCell(6);
    cell.innerHTML = "4.3 &deg;C";
	var cell = row.insertCell(7);
    cell.innerHTML = "5.4 mm";
	var cell = row.insertCell(8);
    cell.innerHTML = "3";	


	var row = header.insertRow(0);
	var cell = row.insertCell(0);
	cell.innerHTML = "Highest";
	cell.className = "small";
	var cell = row.insertCell(1);
	cell.innerHTML = "Average";
	cell.className = "small";	
	var cell = row.insertCell(2);
	cell.innerHTML = "Lowest ";
	cell.className = "small";
	var cell = row.insertCell(3);
	cell.innerHTML = "Highest";
	cell.className = "small";
	var cell = row.insertCell(4);
	cell.innerHTML = "Average";
	cell.className = "small";
	var cell = row.insertCell(5);
	cell.innerHTML = "Lowest ";
	cell.className = "small";
	var row = header.insertRow(0);
	var cell = row.insertCell(0);
	cell.innerHTML = "Month";
	cell.rowSpan = 2;
	var cell = row.insertCell(1);
	cell.innerHTML = "Daytime Maximum";
	cell.colSpan = 3;
	cell.className = "small";
	var cell = row.insertCell(2);
    cell.innerHTML = "Nighttime Minimum";
	cell.colSpan = 3;
	cell.className = "small";	
	var cell = row.insertCell(3);
	cell.innerHTML = "Total";
	cell.rowSpan = 2;
	cell.className = "small";	
	var cell = row.insertCell(4);
	cell.innerHTML = "Rainy Days";
	cell.rowSpan = 2;
	cell.className = "small";
	var row = header.insertRow(0);
	var cell = row.insertCell(0);
	var cell = row.insertCell(1);
	cell.innerHTML = "Temperature";
	cell.colSpan = 6;
	var cell = row.insertCell(2);
	cell.innerHTML = "Rainfall";
	cell.colSpan = 2;
	var outer_div = document.getElementById("tableallmonths");
	outer_div.appendChild(table);
})