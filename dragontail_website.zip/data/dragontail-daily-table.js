$(function() {
    var table = document.createElement("table");
	table.className = "table table-striped table-bordered table-hover table-condensed";
	var header = table.createTHead();
	header.className = "h4";





	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/05/03 09:57";	
    var cell = row.insertCell(1);
    cell.innerHTML = "15.9";
	var cell = row.insertCell(2);
    cell.innerHTML = "5.1";
	var cell = row.insertCell(3);
    cell.innerHTML = "2.50347587719";
	var cell = row.insertCell(4);
    cell.innerHTML = "10.5";
	var cell = row.insertCell(5);
    cell.innerHTML = "1.2 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "