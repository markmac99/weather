$(function() {
Morris.Bar({
 element: 'dragontail-7day-rainfall',
 data: [
    {time: '2016/05/02',
    rain: 2.1    },
    {time: '2016/05/03',
    rain: 1.2    },
    {time: '2016/05/04',
    rain: 0.0    },
    {time: '2016/05/05',
    rain: 0.0    },
    {time: '2016/05/06',
    rain: 0.0    },
    {time: '2016/05/07',
    rain: 0.0    },
    {time: '2016/05/08',
    rain: 2.1    },
    {time: '2016/05/09',
    rain: 0.0    }],
        xkey: 'time',
        ykeys: ['rain'],
        labels: ['Rain'],
        xLabelAngle: 45,
        hideHover: 'auto',
		postUnits: 'mm',
        resize: true
    });
});
