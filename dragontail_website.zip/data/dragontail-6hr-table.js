$(function() {
    var table = document.createElement("table");
	table.className = "table table-striped table-bordered table-hover table-condensed";
	var header = table.createTHead();
	header.className = "h4";





	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "05:58";	
    var cell = row.insertCell(1);
    cell.innerHTML = "13.3 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "86%";
	var cell = row.insertCell(3);
    cell.innerHTML = "4 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "11 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1005.9 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "06:58";	
    var cell = row.insertCell(1);
    cell.innerHTML = "13.6 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "86%";
	var cell = row.insertCell(3);
    cell.innerHTML = "1 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "4 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1006.0 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "07:58";	
    var cell = row.insertCell(1);
    cell.innerHTML = "14.2 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "82%";
	var cell = row.insertCell(3);
    cell.innerHTML = "1 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "6 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1005.8 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "08:58";	
    var cell = row.insertCell(1);
    cell.innerHTML = "15.1 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "77%";
	var cell = row.insertCell(3);
    cell.innerHTML = "1 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "5 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1006.0 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "09:58";	
    var cell = row.insertCell(1);
    cell.innerHTML = "16.0 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "74%";
	var cell = row.insertCell(3);
    cell.innerHTML = "2 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "6 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1005.7 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "10:58";	
    var cell = row.insertCell(1);
    cell.innerHTML = "18.7 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "66%";
	var cell = row.insertCell(3);
    cell.innerHTML = "4 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "10 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1005.4 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "11:58";	
    var cell = row.insertCell(1);
    cell.innerHTML = "20.1 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "59%";
	var cell = row.insertCell(3);
    cell.innerHTML = "6 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "15 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1005.2 hPa";


	var row = header.insertRow(0);
	var cell = row.insertCell(0);
	cell.innerHTML = "Ave";
	cell.className = "small";
	var cell = row.insertCell(1);
	cell.innerHTML = "Max";
	cell.className = "small";
	var row = header.insertRow(0);
	var cell = row.insertCell(0);
	cell.innerHTML = "Time";
	cell.rowSpan = 2;
	var cell = row.insertCell(1);
    cell.innerHTML = "Temp";
	cell.rowSpan = 2;	
	var cell = row.insertCell(2);
	cell.innerHTML = "Humid";
	cell.rowSpan = 2;	
	var cell = row.insertCell(3);
	cell.innerHTML = "Wind mph";
	cell.colSpan = 2;	
	var cell = row.insertCell(4);
	cell.innerHTML = "Rain";
	cell.rowSpan = 2;	
	var cell = row.insertCell(5);
	cell.innerHTML = "Pressure";
	cell.rowSpan = 2;    
	var outer_div = document.getElementById("table6hrs");
	outer_div.appendChild(table);
})