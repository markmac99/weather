$(function() {
    var table = document.createElement("table");
	table.className = "table table-striped table-bordered table-hover table-condensed";
	var header = table.createTHead();
	header.className = "h4";





	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/10 10:00 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "10.3 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "0.3 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "2 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "21 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.6 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/11 10:00 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "15.3 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "6.2 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "6 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "23 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "6.6 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/12 10:00 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "16.9 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "7.4 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "4 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "23 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "6.3 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/13 09:58 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "15.6 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "2.9 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "1 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "10 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/14 09:58 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "16.4 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "7.0 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "1 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "11 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "1.2 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/15 10:00 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "16.5 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "6.9 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "4 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "17 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/16 09:58 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "9.8 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "2.0 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "2 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "17 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "5.1 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/17 09:58 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "11.2 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "0.1 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "2 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "20 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/18 09:58 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "12.0 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "7.0 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "5 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "26 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/19 10:00 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "12.3 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "5.4 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "4 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "28 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/20 09:59 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "19.1 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "4.0 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "2 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "12 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/21 09:59 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "22.0 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "4.2 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "2 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "13 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/22 09:59 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "21.9 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "6.5 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "3 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "15 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/23 09:58 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "18.8 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "1.8 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "3 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "17 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/24 09:57 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "12.6 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "3.3 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "2 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "17 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/25 09:57 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "13.0 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "6.4 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "2 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "21 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "4.2 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/26 09:57 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "11.9 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "4.3 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "3 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "13 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "1.2 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/27 09:57 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "10.7 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "0.5 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "2 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "13 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "1.2 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/28 09:57 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "11.4 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "1.7 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "3 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "16 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.3 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/29 09:57 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "8.2 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "1.3 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "8 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "28 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "9.3 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/04/30 09:57 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "11.7 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "2.8 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "4 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "29 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "3.3 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/05/01 09:57 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "13.8 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "3.8 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "3 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "14 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "2.4 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/05/02 09:57 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "13.2 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "11.0 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "2 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "17 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "2.1 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/05/03 09:57 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "15.9 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "5.1 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "6 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "23 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "1.2 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/05/04 10:00 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "16.8 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "4.3 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "3 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "19 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/05/05 09:58 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "20.1 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "6.4 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "3 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "17 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/05/06 09:58 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "20.6 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "6.8 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "1 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "13 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/05/07 09:58 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "20.4 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "9.0 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "1 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "11 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/05/08 09:58 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "21.2 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "11.8 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "1 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "14 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "2.1 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/05/09 10:00 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "28.0 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "12.2 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "3 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "16 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "2016/05/10 09:58 BST";	
    var cell = row.insertCell(1);
    cell.innerHTML = "29.9 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "13.3 &deg;C";
	var cell = row.insertCell(3);
    cell.innerHTML = "5 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "20 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";


	var row = header.insertRow(0);
	var cell = row.insertCell(0);
	cell.innerHTML = "Day Max";
	cell.className = "small";
	var cell = row.insertCell(1);
	cell.innerHTML = "Night Min";
	cell.className = "small";	
	var cell = row.insertCell(2);
	cell.innerHTML = "Ave";
	cell.className = "small";
	var cell = row.insertCell(3);
	cell.innerHTML = "Max";
	cell.className = "small";
	var row = header.insertRow(0);
	var cell = row.insertCell(0);
	cell.innerHTML = "24 hours ending";
	cell.rowSpan = 2;
	var cell = row.insertCell(1);
    cell.innerHTML = "Temperature";
	cell.colSpan = 2;		
	var cell = row.insertCell(2);
	cell.innerHTML = "Wind mph";
	cell.colSpan = 2;	
	var cell = row.insertCell(3);
	cell.innerHTML = "Rain";
	cell.rowSpan = 2;	   
	var outer_div = document.getElementById("table31days");
	outer_div.appendChild(table);
})