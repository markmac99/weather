$(function() {
    var table = document.createElement("table");
	table.className = "table table-striped table-bordered table-hover table-condensed";
	var header = table.createTHead();
	header.className = "h4";





	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "13:00";	
    var cell = row.insertCell(1);
    cell.innerHTML = "25.5 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "43%";
	var cell = row.insertCell(3);
    cell.innerHTML = "4 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "15 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1006.5 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "14:00";	
    var cell = row.insertCell(1);
    cell.innerHTML = "26.4 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "42%";
	var cell = row.insertCell(3);
    cell.innerHTML = "6 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "17 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1006.6 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "15:00";	
    var cell = row.insertCell(1);
    cell.innerHTML = "28.5 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "39%";
	var cell = row.insertCell(3);
    cell.innerHTML = "4 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "17 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1006.0 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "16:00";	
    var cell = row.insertCell(1);
    cell.innerHTML = "29.5 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "30%";
	var cell = row.insertCell(3);
    cell.innerHTML = "8 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "19 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1005.7 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "17:00";	
    var cell = row.insertCell(1);
    cell.innerHTML = "27.8 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "26%";
	var cell = row.insertCell(3);
    cell.innerHTML = "9 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "18 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1005.4 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "18:00";	
    var cell = row.insertCell(1);
    cell.innerHTML = "27.2 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "31%";
	var cell = row.insertCell(3);
    cell.innerHTML = "9 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "20 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1005.3 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "19:00";	
    var cell = row.insertCell(1);
    cell.innerHTML = "23.5 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "45%";
	var cell = row.insertCell(3);
    cell.innerHTML = "9 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "20 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1005.7 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "20:00";	
    var cell = row.insertCell(1);
    cell.innerHTML = "21.7 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "50%";
	var cell = row.insertCell(3);
    cell.innerHTML = "8 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "17 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1006.2 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "21:00";	
    var cell = row.insertCell(1);
    cell.innerHTML = "19.9 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "57%";
	var cell = row.insertCell(3);
    cell.innerHTML = "6 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "14 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1006.6 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "21:58";	
    var cell = row.insertCell(1);
    cell.innerHTML = "18.6 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "62%";
	var cell = row.insertCell(3);
    cell.innerHTML = "6 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "13 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1006.9 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "22:58";	
    var cell = row.insertCell(1);
    cell.innerHTML = "17.6 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "65%";
	var cell = row.insertCell(3);
    cell.innerHTML = "7 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "17 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1006.9 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "23:59";	
    var cell = row.insertCell(1);
    cell.innerHTML = "16.8 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "67%";
	var cell = row.insertCell(3);
    cell.innerHTML = "8 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "16 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1006.7 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "00:59";	
    var cell = row.insertCell(1);
    cell.innerHTML = "16.2 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "69%";
	var cell = row.insertCell(3);
    cell.innerHTML = "7 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "13 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1006.7 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "01:59";	
    var cell = row.insertCell(1);
    cell.innerHTML = "15.7 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "74%";
	var cell = row.insertCell(3);
    cell.innerHTML = "6 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "12 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1006.5 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "02:59";	
    var cell = row.insertCell(1);
    cell.innerHTML = "15.1 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "74%";
	var cell = row.insertCell(3);
    cell.innerHTML = "7 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "14 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1006.3 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "03:59";	
    var cell = row.insertCell(1);
    cell.innerHTML = "14.5 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "80%";
	var cell = row.insertCell(3);
    cell.innerHTML = "4 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "12 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1006.2 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "04:58";	
    var cell = row.insertCell(1);
    cell.innerHTML = "13.9 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "85%";
	var cell = row.insertCell(3);
    cell.innerHTML = "3 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "9 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1005.9 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "05:58";	
    var cell = row.insertCell(1);
    cell.innerHTML = "13.3 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "86%";
	var cell = row.insertCell(3);
    cell.innerHTML = "4 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "11 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1005.9 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "06:58";	
    var cell = row.insertCell(1);
    cell.innerHTML = "13.6 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "86%";
	var cell = row.insertCell(3);
    cell.innerHTML = "1 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "4 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1006.0 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "07:58";	
    var cell = row.insertCell(1);
    cell.innerHTML = "14.2 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "82%";
	var cell = row.insertCell(3);
    cell.innerHTML = "1 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "6 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1005.8 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "08:58";	
    var cell = row.insertCell(1);
    cell.innerHTML = "15.1 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "77%";
	var cell = row.insertCell(3);
    cell.innerHTML = "1 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "5 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1006.0 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "09:58";	
    var cell = row.insertCell(1);
    cell.innerHTML = "16.0 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "74%";
	var cell = row.insertCell(3);
    cell.innerHTML = "2 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "6 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1005.7 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "10:58";	
    var cell = row.insertCell(1);
    cell.innerHTML = "18.7 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "66%";
	var cell = row.insertCell(3);
    cell.innerHTML = "4 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "10 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1005.4 hPa";


	var row = table.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "11:58";	
    var cell = row.insertCell(1);
    cell.innerHTML = "20.1 &deg;C";
	var cell = row.insertCell(2);
    cell.innerHTML = "59%";
	var cell = row.insertCell(3);
    cell.innerHTML = "6 mph";
	var cell = row.insertCell(4);
    cell.innerHTML = "15 mph";
	var cell = row.insertCell(5);
    cell.innerHTML = "0.0 mm";
	var cell = row.insertCell(6);
    cell.innerHTML = "1005.2 hPa";


	var row = header.insertRow(0);
	var cell = row.insertCell(0);
	cell.innerHTML = "Ave";
	cell.className = "small";
	var cell = row.insertCell(1);
	cell.innerHTML = "Max";
	cell.className = "small";
	var row = header.insertRow(0);
	var cell = row.insertCell(0);
	cell.innerHTML = "Time";
	cell.rowSpan = 2;
	var cell = row.insertCell(1);
    cell.innerHTML = "Temp";
	cell.rowSpan = 2;	
	var cell = row.insertCell(2);
	cell.innerHTML = "Humid";
	cell.rowSpan = 2;	
	var cell = row.insertCell(3);
	cell.innerHTML = "Wind mph";
	cell.colSpan = 2;	
	var cell = row.insertCell(4);
	cell.innerHTML = "Rain";
	cell.rowSpan = 2;	
	var cell = row.insertCell(5);
	cell.innerHTML = "Pressure";
	cell.rowSpan = 2;    
	var outer_div = document.getElementById("table24hrs");
	outer_div.appendChild(table);
})